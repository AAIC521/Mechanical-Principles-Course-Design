from sko.GA import GA
from numpy import pi
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve


# 双曲柄机构，定义你的方程组
def equations_1_shuangqubing(vars, theta_1, l, m, n):
    theta_2 = vars
    eq1 = (
        l**2
        + m**2
        - n**2
        + 2 * l * m * np.cos(theta_1 - theta_2)
        + 1
        - 2 * l * np.cos(theta_1)
        - 2 * m * np.cos(theta_2)
    )

    return eq1


# 双曲柄机构，定义你的方程组
def equations_2_shuangqubing(vars, theta_1, l, m, n):
    theta_3 = vars
    eq2 = (
        l**2
        + n**2
        - m**2
        - 2 * l * n * np.cos(theta_3 - theta_1)
        - 2 * l * np.cos(theta_1)
        + 2 * n * np.cos(theta_3)
        + 1
    )

    return eq2


# 双曲柄，杆件角速度方程组
def equations_3_shuangqubing(vars, theta_1, theta_2, theta_3, l, m, n, w_1):
    w_2, w_3 = vars
    eq1 = (
        -2 * l * m * np.sin(theta_1 - theta_2) * (w_1 - w_2)
        + 2 * l * np.sin(theta_1) * w_1
        + 2 * m * np.sin(theta_2) * w_2
    )

    eq2 = (
        2 * l * n * np.sin(theta_3 - theta_1) * (w_3 - w_1)
        + 2 * l * np.sin(theta_1) * w_1
        - 2 * n * np.sin(theta_3) * w_3
    )

    return np.array([eq1, eq2]).flatten()


# 曲柄滑块，定义你的方程组
def equations_1_qubinghuakuai(vars, theta_1, r, l, e):
    theta_2, s = vars
    eq1 = r * np.cos(theta_1) + l * np.cos(theta_2) - e
    eq2 = r * np.sin(theta_1) + l * np.sin(theta_2) - s
    return np.array([eq1, eq2]).flatten()


# 曲柄滑块，速度方程组
def equations_2_qubinghuakuai(vars, theta_1, theta_2, r, l, w_1):
    w_2, v = vars
    eq1 = -r * np.sin(theta_1) * w_1 - l * np.sin(theta_2) * w_2
    eq2 = r * np.cos(theta_1) * w_1 + l * np.cos(theta_2) * w_2 - v
    return np.array([eq1, eq2]).flatten()


# 双曲柄，计算杆件角速度
def get_w(theta_1_list, theta_2_list, theta_3_list, l, m, n, w_1):
    w_2_list = []  # 创建一个新的列表
    w_3_list = []  # 创建一个新的列表

    for i in range(len(theta_1_list)):
        guess = [0, 0]
        result = fsolve(
            equations_3_shuangqubing,
            guess,
            args=(
                theta_1_list[i],
                theta_2_list[i],
                theta_3_list[i],
                l,
                m,
                n,
                w_1,
            ),
        )
        w_2_list.append(result[0])
        w_3_list.append(result[1])

    return w_3_list


#  曲柄滑块机构，计算杆件角度和滑块位移
def get_v(s_list):
    v_list = []
    for i in range(1, len(s_list)):
        v = (s_list[i] - s_list[i - 1]) * 7000 / 6
        v_list.append(v)
    v_list.append(v_list[0])

    return v_list - np.mean(v_list)


#  曲柄滑块机构，加速度
def get_a(v_list):
    a_list = []
    for i in range(1, len(v_list)):
        a = (v_list[i] - v_list[i - 1]) / (6 / 7 / 1000)
        a_list.append(a)
    a_list.append(a_list[0])

    return a_list - np.mean(a_list)


#  双曲柄机构，计算杆件角度
def get_theta(theta_func, theta_1_list, l, m, n):
    theta_list = []  # 创建一个新的列表

    for theta_1 in theta_1_list:

        guess = 0

        if theta_1 == 0:
            guess = -1.5
        else:
            guess = prev_angle

        # 使用fsolve求解
        result = fsolve(theta_func, guess, args=(theta_1, l, m, n))

        # 将结果限制在-pi到pi之间
        prev_angle = (result + pi) % (2 * pi) - pi

        theta_list.append(prev_angle)

    return theta_list


#  曲柄滑块机构，计算杆件角度和滑块位移
def get_theta_s(theta_func, theta_1_list, r, l, e, prev_angle=0, prev_s=0):
    theta_list = []  # 创建一个新的列表
    s_list = []
    for theta_1 in theta_1_list:
        guess_theta = 0 if theta_1 == 0 else prev_angle
        guess_s = 0 if theta_1 == 0 else prev_s
        guess = [guess_theta, guess_s]
        result = fsolve(theta_func, guess, args=(theta_1, r, l, e))
        prev_angle = (result[0] + pi) % (2 * pi) - pi
        prev_s = result[1]
        theta_list.append(prev_angle)
        s_list.append(prev_s)
    return theta_list, s_list


# 曲柄滑块，计算滑块压力角
def get_yalijiao(theta_2_list):
    yalijiao_list = []
    for theta_2 in theta_2_list:
        delta_theta = pi / 2 - theta_2
        if delta_theta < 0:
            delta_theta = -delta_theta
        if delta_theta > pi:
            delta_theta = delta_theta % pi
        if delta_theta > pi / 2:
            delta_theta = pi - delta_theta
        yalijiao_list.append(delta_theta)
    return yalijiao_list


# 优化结果[ 88.33982484  99.02232743  37.85537091 -13.25424307 -23.70097573 -0.75480115 149.76952327]
l = 88.33982484
m = 99.02232743
n = 37.85537091
p = -13.25424307
h = -23.70097573
e = -0.75480115
j = 149.76952327

w_1 = 7 / 3 * pi

# 原动件角度
theta_1_list = np.linspace(0, 2 * pi - 0.0001, 1000)

# 双曲柄角度
theta_2_list = get_theta(
    equations_1_shuangqubing,
    theta_1_list,
    l=l / np.sqrt(p**2 + h**2),
    m=m / np.sqrt(p**2 + h**2),
    n=n / np.sqrt(p**2 + h**2),
) + np.arctan(p / h)

theta_3_list = get_theta(
    equations_2_shuangqubing,
    theta_1_list,
    l=l / np.sqrt(p**2 + h**2),
    m=m / np.sqrt(p**2 + h**2),
    n=n / np.sqrt(p**2 + h**2),
) + np.arctan(p / h)
# 曲柄滑块机构，连杆角度和滑块位移
theta_4_list, s_list = get_theta_s(
    equations_1_qubinghuakuai, theta_3_list, r=n, l=j, e=e
)
# 计算曲柄滑块机构中的压力角
yalijiao_list = get_yalijiao(theta_4_list)

# 计算双曲柄机构中的角速度
w_3_list = get_w(theta_1_list, theta_2_list, theta_3_list, l, m, n, w_1)

# 计算曲柄滑块机构中的速度
v_list = get_v(s_list)

a_list = get_a(v_list)

yalijiao_max = max(yalijiao_list)  # 最大压力角
s_max_index = np.argmax(s_list)  # 最大位移的索引
s_min_index = np.argmin(s_list)  # 最小位移的索引
back_time = 0  # 初始化回程时间
# 计算回程时间，回程时间永远小于总时间一半
if np.abs(s_max_index - s_min_index) < 500:
    back_time = np.abs(s_max_index - s_min_index)
else:
    back_time = 1000 - np.abs(s_max_index - s_min_index)
K = (1000 - back_time) / back_time  # 计算K值
s = s_list[s_max_index] - s_list[s_min_index]

print("最大压力角：", np.rad2deg(yalijiao_max))
print("最大位移：", s)
print("K值：", K)
print(np.sum(v_list) * 6 / 7000)
print(np.sum(a_list) * 6 / 7000)
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置中文字体
plt.rcParams["font.sans-serif"] = ["SimHei"]  # 'SimHei' 是一种常用的中文字体
plt.rcParams["axes.unicode_minus"] = False  # 正确显示负号

# 第一幅图：位移 vs Theta_1
plt.figure(figsize=(10, 6))
plt.plot(
    np.rad2deg(theta_1_list),
    s_list,
    label="位移 vs Theta_1",
    color="blue",  # 添加颜色以区分不同的曲线
    linewidth=2,  # 设置线宽
    marker="o",  # 设置数据点的形状
    markersize=3,  # 设置数据点的大小
    markevery=50,  # 设置数据点的间隔
)
plt.xlabel("Theta_1 (度)")  # x轴标签改为度数
plt.ylabel("位移")  # y轴标签改为位移
plt.title("位移与Theta_1的关系")  # 标题改为位移与Theta_1的关系
plt.legend()
plt.grid(True)
plt.tight_layout()  # 调整布局以防止重叠
plt.show()

# 第二幅图：压力角 vs Theta_1
plt.figure(figsize=(10, 6))
plt.plot(
    np.rad2deg(theta_1_list),
    np.rad2deg(yalijiao_list),
    label="压力角 vs Theta_1",
    color="red",  # 添加颜色以区分不同的曲线
    linewidth=2,  # 设置线宽
    linestyle="--",  # 设置线型为虚线
    marker="s",  # 设置数据点的形状
    markersize=3,  # 设置数据点的大小
    markevery=50,  # 设置数据点的间隔
)
plt.xlabel("Theta_1 (度)")  # x轴标签改为度数
plt.ylabel("压力角 (度)")  # y轴标签改为压力角
plt.title("压力角与Theta_1的关系")  # 标题改为压力角与Theta_1的关系
plt.legend()
plt.grid(True)
plt.tight_layout()  # 调整布局以防止重叠
plt.show()


# 绘制角速度 vs Theta_1
plt.figure(figsize=(10, 6))
plt.plot(
    np.rad2deg(theta_1_list),  # 将弧度转换为度
    w_3_list,  # 角速度列表
    label="角速度 vs Theta_1",
    color="green",  # 设置颜色
    linewidth=2,  # 设置线宽
    linestyle="-",  # 设置线型
    marker="x",  # 设置数据点的形状
    markersize=3,  # 设置数据点的大小
    markevery=50,  # 设置数据点的间隔
)
plt.xlabel("Theta_1 (度)")
plt.ylabel("角速度")
plt.title("角速度与Theta_1的关系")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# 绘制速度 vs Theta_1
plt.figure(figsize=(10, 6))
plt.plot(
    np.rad2deg(theta_1_list),  # 将弧度转换为度
    v_list,  # 速度列表
    label="速度 vs Theta_1",
    color="purple",  # 设置颜色
    linewidth=2,  # 设置线宽
    linestyle="-",  # 设置线型
    marker="*",  # 设置数据点的形状
    markersize=3,  # 设置数据点的大小
    markevery=50,  # 设置数据点的间隔
)
plt.xlabel("Theta_1 (度)")
plt.ylabel("速度")
plt.title("速度与Theta_1的关系")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# 绘制加速度 vs Theta_1
plt.figure(figsize=(10, 6))
plt.plot(
    np.rad2deg(theta_1_list),  # 将弧度转换为度
    get_a(v_list),  # 加速度列表
    label="加速度 vs Theta_1",
    color="orange",  # 设置颜色
    linewidth=2,  # 设置线宽
    linestyle="-",  # 设置线型
    marker="^",  # 设置数据点的形状
    markersize=3,  # 设置数据点的大小
    markevery=50,  # 设置数据点的间隔
)
plt.xlabel("Theta_1 (度)")
plt.ylabel("加速度")
plt.title("加速度与Theta_1的关系")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

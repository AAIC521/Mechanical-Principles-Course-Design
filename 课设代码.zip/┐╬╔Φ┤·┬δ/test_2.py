from sko.GA import GA
from numpy import pi
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from scipy.optimize import fsolve


# 定义你的方程组
def equations_1(vars, theta_1, r, l, e):
    theta_2, s = vars
    eq1 = r * np.cos(theta_1) + l * np.cos(theta_2) - e
    eq2 = r * np.sin(theta_1) + l * np.sin(theta_2) - s
    return eq1, eq2


# [3.07884661 9.94875506 3.12073256]
def get_theta_s(
    theta_func,
    theta_1_list,
    prev_angle=0,
    prev_s=0,
    r=3.07884661,
    l=9.94875506,
    e=3.12073256,
):
    theta_list = []  # 创建一个新的列表
    s_list = []
    for theta_1 in theta_1_list:
        guess_theta = 0 if theta_1 == 0 else prev_angle
        guess_s = 0 if theta_1 == 0 else prev_s
        guess = [guess_theta, guess_s]
        result = fsolve(theta_func, guess, args=(theta_1, r, l, e))
        prev_angle = (result[0] + pi) % (2 * pi) - pi
        prev_s = result[1]
        theta_list.append(prev_angle)
        s_list.append(prev_s)
    return theta_list, s_list


def get_yalijiao(theta_2_list):
    yalijiao_list = []
    for theta_2 in theta_2_list:
        delta_theta = pi / 2 - theta_2
        if delta_theta < 0:
            delta_theta = -delta_theta
        if delta_theta > pi:
            delta_theta = delta_theta % pi
        if delta_theta > pi / 2:
            delta_theta = pi - delta_theta
        yalijiao_list.append(delta_theta)
    return yalijiao_list


theta_1_list = np.linspace(0, 2 * pi - 0.0001, 1000)
theta_2_list, s_list = get_theta_s(equations_1, theta_1_list)
yalijiao_list = get_yalijiao(theta_2_list)

# 输出最大位移和最大压力角
print("S:", max(s_list) - min(s_list))
print(np.rad2deg(max(yalijiao_list)))

# 设置支持中文的字体
plt.rcParams["font.sans-serif"] = ["SimHei"]  # 'SimHei' 是黑体的意思
plt.rcParams["axes.unicode_minus"] = False  # 用来正常显示负号

plt.figure(figsize=(12, 6))

# 绘制曲柄角度theta_2随曲柄角度theta_1的变化
plt.subplot(1, 2, 1)
plt.plot(np.rad2deg(theta_1_list), np.rad2deg(theta_2_list), label="Theta 2")
plt.title("曲柄角度 Theta 2")
plt.xlabel("曲柄角度 Theta 1 (rad)")
plt.ylabel("曲柄角度 Theta 2 (rad)")
plt.grid(True)
plt.legend()

# 绘制滑块位移s随曲柄角度theta_1的变化
plt.subplot(1, 2, 2)
plt.plot(np.rad2deg(theta_1_list), s_list, label="Displacement s", color="red")
plt.title("滑块位移 S")
plt.xlabel("曲柄角度 Theta 1 (rad)")
plt.ylabel("滑块位移 S (m)")
plt.grid(True)
plt.legend()

# 绘制压力角随曲柄角度theta_1的变化
plt.figure()
plt.plot(np.rad2deg(theta_1_list), np.rad2deg(yalijiao_list), label="压力角")
plt.title("压力角")
plt.xlabel("曲柄角度 Theta 1 (rad)")
plt.ylabel("压力角 (rad)")
plt.grid(True)
plt.legend()

# 显示图像
plt.tight_layout()
plt.show()

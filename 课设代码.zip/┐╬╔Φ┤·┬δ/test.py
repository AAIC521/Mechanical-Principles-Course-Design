from GeneticAlgorithm import GeneticAlgorithm as GA
from numpy import pi
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve


# 双曲柄机构，定义你的方程组
def equations_1_shuangqubing(vars, theta_1, l, m, n):
    theta_2 = vars
    eq1 = (
        l**2
        + m**2
        - n**2
        + 2 * l * m * np.cos(theta_1 - theta_2)
        + 1
        - 2 * l * np.cos(theta_1)
        - 2 * m * np.cos(theta_2)
    )

    return eq1


# 双曲柄机构，定义你的方程组
def equations_2_shuangqubing(vars, theta_1, l, m, n):
    theta_3 = vars
    eq2 = (
        l**2
        + n**2
        - m**2
        - 2 * l * n * np.cos(theta_3 - theta_1)
        - 2 * l * np.cos(theta_1)
        + 2 * n * np.cos(theta_3)
        + 1
    )

    return eq2


# 曲柄滑块，定义你的方程组
def equations_1_qubinghuakuai(vars, theta_1, r, l, e):
    theta_2, s = vars
    eq1 = r * np.cos(theta_1) + l * np.cos(theta_2) - e
    eq2 = r * np.sin(theta_1) + l * np.sin(theta_2) - s
    return np.array([eq1, eq2]).ravel()


#  双曲柄机构，计算杆件角度
def get_theta(theta_func, theta_1_list, l, m, n):
    theta_list = []  # 创建一个新的列表

    for theta_1 in theta_1_list:

        guess = 0

        if theta_1 == 0:
            guess = -1.5
        else:
            guess = prev_angle

        # 使用fsolve求解
        result = fsolve(theta_func, guess, args=(theta_1, l, m, n))

        # 将结果限制在-pi到pi之间
        prev_angle = (result + pi) % (2 * pi) - pi

        theta_list.append(prev_angle)

    return theta_list


#  曲柄滑块机构，计算杆件角度和滑块位移
def get_theta_s(
    theta_func,
    theta_1_list,
    r,
    l,
    e,
    prev_angle=0,
    prev_s=0,
):
    theta_list = []  # 创建一个新的列表
    s_list = []
    for theta_1 in theta_1_list:
        guess_theta = 0 if theta_1 == 0 else prev_angle
        guess_s = 0 if theta_1 == 0 else prev_s
        guess = [guess_theta, guess_s]
        result = fsolve(theta_func, guess, args=(theta_1, r, l, e))
        prev_angle = (result[0] + pi) % (2 * pi) - pi
        prev_s = result[1]
        theta_list.append(prev_angle)
        s_list.append(prev_s)
    return theta_list, s_list


# 曲柄滑块，计算滑块压力角
def get_yalijiao(theta_2_list):
    yalijiao_list = []
    for theta_2 in theta_2_list:
        delta_theta = pi / 2 - theta_2
        if delta_theta < 0:
            delta_theta = -delta_theta
        if delta_theta > pi:
            delta_theta = delta_theta % pi
        if delta_theta > pi / 2:
            delta_theta = pi - delta_theta
        yalijiao_list.append(delta_theta)
    return yalijiao_list


alpha_angle = 5
alpha_s = 2.5
alpha_length = 1
alpha_K = 5


# 定义目标函数
def func(vars):
    l, m, n, p, h, e, j = vars

    # 机构存在的约束条件
    is_notOK = False
    if np.sqrt(p**2 + h**2) >= np.min([l, m, n]):
        is_notOK = True
    if np.sqrt(p**2 + h**2) + 2 * np.max([l, m, n]) > np.sum([l, m, n]):
        is_notOK = True
    if j < np.abs(e) + n:
        is_notOK = True
    if is_notOK:
        return 1000

    # 原动件角度
    theta_1_list = np.linspace(0, 2 * pi - 0.0001, 1000)

    # 双曲柄的连架杆，也即曲柄滑块的连架杆角度
    theta_3_list = get_theta(
        equations_2_shuangqubing,
        theta_1_list,
        l=l / np.sqrt(p**2 + h**2),
        m=m / np.sqrt(p**2 + h**2),
        n=n / np.sqrt(p**2 + h**2),
    ) + np.arctan(p / h)
    # 曲柄滑块机构，连杆角度和滑块位移
    theta_4_list, s_list = get_theta_s(
        equations_1_qubinghuakuai, theta_3_list, r=n, l=j, e=e
    )
    # 计算曲柄滑块机构中的压力角
    yalijiao_list = get_yalijiao(theta_4_list)

    # K一票否决
    s_max_index = np.argmax(s_list)  # 最大位移的索引
    s_min_index = np.argmin(s_list)  # 最小位移的索引
    back_time = 0  # 初始化回程时间
    # 计算回程时间，回程时间永远小于总时间一半
    if np.abs(s_max_index - s_min_index) < 500:
        back_time = np.abs(s_max_index - s_min_index)
    else:
        back_time = 1000 - np.abs(s_max_index - s_min_index)
    K = (1000 - back_time) / back_time  # 计算K值
    if K < 1.5:
        return 1000

    # 行程一票否决
    delta_s = s_list[s_max_index] - s_list[s_min_index]
    if delta_s < 30 or delta_s > 100:
        return 1000

    # 计算得分
    score_angle = alpha_angle * np.max(yalijiao_list) / (pi / 2)
    score_s = alpha_s * np.abs(65 - delta_s) / 35
    score_length = alpha_length * np.sum(np.array(vars) ** 2) / (1000**2 * 7)
    score_K = alpha_K * np.exp(1.5 - K)

    print(
        "score_angle: {:.2f}".format(score_angle),
        "score_s: {:.2f}".format(score_s),
        "score_length: {:.2f}".format(score_length),
        "score_K: {:.2f}".format(score_K),
    )

    return (score_angle + score_s + score_length + score_K) / (
        alpha_angle + alpha_s + alpha_length + alpha_K
    )


# 初始化遗传算法对象
ga = GA(
    fitness_func=func,
    gene_length=7,
    pop_size=100,
    max_iter=300,
    lb=[0, 0, 0, -175, -175, -175, 0],
    ub=[150, 150, 150, 150, 150, 150, 150],
    # ub=[175, 175, 175, 175, 175, 175, 175],
    # ub=[200, 200, 200, 200, 200, 200, 200],
)

# 执行遗传算法搜索最优解
best_vars, best_y = ga.run()

print("最优解：", best_vars)
print("最优目标函数值：", best_y)

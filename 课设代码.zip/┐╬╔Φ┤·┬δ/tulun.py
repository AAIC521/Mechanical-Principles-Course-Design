import numpy as np
from numpy import pi
import matplotlib.pyplot as plt


R = 100


# �����Ӻ���
def fun_1(x):
    a = -5184 / (25 * (pi**3))
    b = 1224 / (5 * (pi**2))
    return a * (x**3) + b * (x**2)


def fun_1_d(x):
    a = -5184 / (25 * (pi**3))
    b = 1224 / (5 * (pi**2))
    return 3 * a * (x**2) + 2 * b * x


def fun_2(x):
    return 80 / pi * x - 40 / 9


def fun_2_d(x):
    return 80 / pi


def fun_3(x):
    a = -67392 / (25 * (pi**3))
    b = 237888 / (25 * (pi**2))
    c = -274944 / (25 * pi)
    d = 106424 / 25
    return a * (x**3) + b * (x**2) + c * x + d


def fun_3_d(x):
    a = -67392 / (25 * (pi**3))
    b = 237888 / (25 * (pi**2))
    c = -274944 / (25 * pi)
    return 3 * a * (x**2) + 2 * b * x + c


def fun_4(x):
    a = 810 / (pi**3)
    b = -4050 / (pi**2)
    c = 6480 / pi
    d = -3240
    return a * (x**3) + b * (x**2) + c * x + d


def fun_4_d(x):
    a = 810 / (pi**3)
    b = -4050 / (pi**2)
    c = 6480 / pi
    return 3 * a * (x**2) + 2 * b * x + c


# ����������
def fun(x):
    if 0 <= x <= 5 * pi / 9:
        return fun_1(x)
    elif 5 * pi / 9 < x <= 19 * pi / 18:
        return fun_2(x)
    elif 19 * pi / 18 < x <= 4 * pi / 3:
        return fun_3(x)
    elif 4 * pi / 3 < x <= 2 * pi:
        return fun_4(x)


def fun_d(x):
    if 0 <= x <= 5 * pi / 9:
        return fun_1_d(x)
    elif 5 * pi / 9 < x <= 19 * pi / 18:
        return fun_2_d(x)
    elif 19 * pi / 18 < x <= 4 * pi / 3:
        return fun_3_d(x)
    elif 4 * pi / 3 < x <= 2 * pi:
        return fun_4_d(x)


# �����귽��
def polar_fun(theta):
    r = fun(theta) + R
    return r, theta


def polar_fun_d(theta):
    a = fun_d(theta) * np.sin(theta) + (fun(theta) + R) * np.cos(theta)
    b = fun_d(theta) * np.cos(theta) - (fun(theta) + R) * np.sin(theta)
    return a / b


def polar_fun_k(theta):
    return -1 / polar_fun_d(theta)


# Initialize global variables
prev_X, prev_Y = None, None


def Fun(theta, l, direction):
    global prev_X, prev_Y

    # Calculate k based on polar_fun_k(theta)
    k = polar_fun_k(theta)
    cos = np.abs(1 / np.sqrt(1 + k**2))
    sin = np.abs(k * cos)

    # Adjust signs of cos and sin based on direction
    if direction == "up":
        if k < 0:
            cos = -cos
    elif direction == "down":
        sin = -sin
        if k > 0:
            cos = -cos

    # Calculate X and Y
    X = polar_fun(theta)[0] * np.cos(theta) + l * cos
    Y = polar_fun(theta)[0] * np.sin(theta) + l * sin

    # Threshold check
    therd = 1
    if prev_X is not None and prev_Y is not None:
        if np.abs(X - prev_X) > therd or np.abs(Y - prev_Y) > therd:
            cos = -cos
            sin = -sin
            X = polar_fun(theta)[0] * np.cos(theta) + l * cos
            Y = polar_fun(theta)[0] * np.sin(theta) + l * sin

    # Update prev_X and prev_Y
    prev_X, prev_Y = X, Y

    return X, Y


# �������ݵ�
l_1 = 0
l_2 = 30
theta_1 = np.linspace(0.00001, pi - 0.00001, 1000)
theta_2 = np.linspace(pi + 0.00001, pi * 2 - 0.00001, 1000)

X_1, Y_1 = zip(*[Fun(x, l_1, "down") for x in theta_1])
X_2, Y_2 = zip(*[Fun(x, l_1, "down") for x in theta_2])

X = X_1 + X_2
Y = Y_1 + Y_2

# ���Ƶ�һ������
plt.plot(X, Y, label="Curve 1")

# # ���Ƶڶ�������
X_1, Y_1 = zip(*[Fun(x, l_2, "up") for x in theta_1])
X_2, Y_2 = zip(*[Fun(x, l_2, "up") for x in theta_2])

X = X_1 + X_2
Y = Y_1 + Y_2

plt.plot(X, Y, label="Curve 2")


# ����ͼ��
plt.legend()

# ���õ�λ�������
plt.axis("equal")

# ��ʾͼ��
plt.show()


plt.rcParams["font.sans-serif"] = ["SimHei"]  # ָ��Ĭ������Ϊ����
plt.rcParams["axes.unicode_minus"] = False  # �������'-'��ʾΪ���������
# λ��ͼ��
theta_fun = np.linspace(0.00001, 2 * pi - 0.00001, 10000)
s_list = [fun(theta) for theta in theta_fun]

# �ֽ��ĽǶ�
dividing_thetas = [0, 5 * pi / 9, 19 * pi / 18, 4 * pi / 3, 2 * pi]

# ����ֽ���λ��ֵ
dividing_s = [fun(theta) for theta in dividing_thetas]

# ���ֽ��ת��Ϊ����
dividing_degrees = np.rad2deg(dividing_thetas)

# ����λ��ͼ��
plt.plot(np.rad2deg(theta_fun), s_list, label="S")

# �ڷֽ�㴦���ӱ��
plt.scatter(dividing_degrees, dividing_s, color="red", label="Dividing Points")

# ���ӷֽ���Աߵ��ı���ǩ������
labels = ["A", "B", "C", "D", "E"]
for i, (degree, displacement) in enumerate(zip(dividing_degrees, dividing_s)):
    plt.text(
        degree - 15, displacement, f"{labels[i]} ({degree:.1f}, {displacement:.1f})"
    )

# ���Ӻ�������ǩ
function_labels = ["f_1", "f_2", "f_3", "f_4"]
function_positions = [
    (5 * pi / 18 + 0.2, fun(5 * pi / 18)),
    (29 * pi / 36 + 0.2, fun(29 * pi / 36)),
    (43 * pi / 36 + 0.2, fun(43 * pi / 36)),
    (5 * pi / 3 + 0.2, fun(5 * pi / 3)),
]

for label, (theta, r) in zip(function_labels, function_positions):
    plt.text(np.rad2deg(theta), r, label)

# ���Ӻ����ǩ
plt.xlabel("�Ƕ� (��)")

# ���������ǩ
plt.ylabel("λ�ƣ�mm��")

# ����ͼ�����
plt.title("λ��ͼ��")

# ����ͼ��
plt.legend()
plt.legend(loc="upper left")
# ��ʾͼ��
plt.show()

# �ٶ�ͼ��
v_list = [(s_list[i] - s_list[i - 1]) * 70000 / 6 for i in range(1, len(s_list))]
v_list.append(v_list[0])
v_list = v_list - np.mean(v_list)

plt.plot(np.rad2deg(theta_fun), v_list, label="V")

# ����ͼ��
plt.legend()


# ��ʾͼ��
plt.show()

# ���ٶ�ͼ��
a_list = [(v_list[i] - v_list[i - 1]) * 70000 / 6 for i in range(1, len(v_list))]
a_list.append(a_list[0])
a_list = a_list - np.mean(a_list)

plt.plot(np.rad2deg(theta_fun), a_list, label="A")

# ����ͼ��
plt.legend()


# ��ʾͼ��
plt.show()

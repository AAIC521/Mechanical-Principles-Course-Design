import numpy as np
from tqdm import tqdm


class GeneticAlgorithm:
    def __init__(
        self,
        fitness_func,
        gene_length,
        lb,
        ub,
        pop_size=50,
        max_iter=1000,
        crossover_rate=0.8,
        mutation_rate=0.02,
    ):
        self.fitness_func = fitness_func
        self.gene_length = gene_length
        self.lb = np.array(lb)
        self.ub = np.array(ub)
        self.pop_size = pop_size
        self.max_iter = max_iter
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.population = self.initialize_population()
        self.best_individual = None
        self.best_fitness = float("inf")

    def initialize_population(self):
        return np.random.uniform(self.lb, self.ub, (self.pop_size, self.gene_length))

    def tournament_selection(self, fitness):
        selected_indices = []
        for _ in range(len(self.population)):
            indices = np.random.choice(len(self.population), 3, replace=False)
            selected_indices.append(indices[np.argmin(fitness[indices])])
        return self.population[selected_indices]

    def single_point_crossover(self, parent1, parent2):
        if np.random.rand() < self.crossover_rate:
            point = np.random.randint(1, self.gene_length)
            child1 = np.concatenate((parent1[:point], parent2[point:]))
            child2 = np.concatenate((parent2[:point], parent1[point:]))
            return child1, child2
        else:
            return parent1.copy(), parent2.copy()

    def mutate(self, individual):
        for i in range(self.gene_length):
            if np.random.rand() < self.mutation_rate:
                individual[i] = np.random.uniform(self.lb[i], self.ub[i])
        return individual

    def run(self):
        with tqdm(total=self.max_iter, desc="Generation") as pbar:
            for generation in range(self.max_iter):
                fitness = np.array([self.fitness_func(ind) for ind in self.population])
                best_idx = np.argmin(fitness)
                if fitness[best_idx] < self.best_fitness:
                    self.best_fitness = fitness[best_idx]
                    self.best_individual = self.population[best_idx].copy()
                    print(
                        f"\nGeneration {generation}: Best Fitness = {self.best_fitness}"
                    )
                    print(f"Best Individual = {self.best_individual}")

                selected_population = self.tournament_selection(fitness)
                children = []
                for i in range(0, self.pop_size, 2):
                    parent1, parent2 = (
                        selected_population[i],
                        selected_population[i + 1],
                    )
                    child1, child2 = self.single_point_crossover(parent1, parent2)
                    children.append(self.mutate(child1))
                    children.append(self.mutate(child2))

                # 精英保留
                children[0] = self.best_individual.copy()
                self.population = np.array(children)
                pbar.update(1)

        return self.best_individual, self.best_fitness
